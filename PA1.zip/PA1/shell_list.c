#include "shell_list.h"
#include "list_of_list.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
void print_List(Node*head);
Node* index_Node(Node* list, int index);
void swap_Nodes(Node** list, int pos1, int pos2);

Node *List_Load_From_File(char *filename)
{
    int size;
    int i;
    FILE* fh = fopen(filename, "rb");
	fseek(fh, 0, SEEK_END);
	size = ftell(fh);
	size = (size / sizeof(long));
    
    if(size == 0)
        return NULL; 
    
	fclose(fh);
	fh = fopen(filename, "rb");

	long buffer;
    Node * head;
    Node * temp = malloc(sizeof(Node));
    fread(&buffer, sizeof(long), 1,fh);
    temp->value = buffer;
    temp->next = NULL;
    head = temp;
	for(i = 1; i < size; i++)
	{
		fread(&buffer, sizeof(long), 1,fh);
        Node* temp2 = malloc(sizeof(Node));
        temp -> next = temp2;
        temp2 -> value = buffer;
        temp2 -> next = NULL;
    	temp = temp2;
  	} 
    temp = head;
    //print_List(temp);

	fclose(fh);
   
    return head;
}

int List_Save_To_File(char *filename, Node *list)
{
    FILE* fh = fopen(filename, "wb");
    Node * temp;
    temp = list;
    int size = 0;
    do
    {
        fwrite(&list->value, sizeof(long), 1, fh);
        list = list -> next;
        size ++;
    } while(list != NULL); 
    fclose(fh);
    
    return size;
}

Node *List_Shellsort(Node* list, long *n_comp)
{
    Node* temp = NULL; //to get size
    Node* head = NULL; //holds head of linked list
    Node* temp_r = NULL;
    Node* temp_ik = NULL;

    int i;
    int size = 0;
    temp = list;
    do
    {
        temp = temp -> next;
        size ++;
    } while(temp != NULL); 
    
    //head = list;
    int start_val = (size - 1) / 3;
    for(int k = (start_val * 3) + 1; k > 0; k = (k-1) / 3)
    {
        for(int j = k; j < size; j++)
        {
            i = j;
            temp_r = index_Node(list, j);
            while(i >= k)
            {
                temp_ik = index_Node(list, i-k);
                if(temp_ik -> value > temp_r ->value)
                {
                    swap_Nodes(&list, i, i-k);
                    i -= k;
                    *n_comp = *n_comp + 1;
                }
                else
                {
                    i = 0; //max j value is 1 so this is an exit statement
                }
            } 
            *n_comp = *n_comp + 1;        
        }
    } 
    //print_List(list);
    return list;
}

Node* index_Node(Node* head, int index)
{
    Node* current = NULL;
    current = head; 
  
    int count = 0; 
    while (current != NULL) { 
        if (count == index) 
            return (current); 
        count++; 
        current = current->next; 
    }
    return current; 
    
}

void swap_Nodes(Node** head, int pos1, int pos2)
{

    if(pos1 == pos2)
        return;
    

    if ((pos1 < 0) || (pos2 < 0))
        return;

    Node* node1 = NULL;
    Node* node2 = NULL;
    Node* prev1 = NULL;
    Node* prev2 = NULL;

    Node* tmp = *head;

    int i = 0;

    prev1 = index_Node(tmp, pos1 - 1);
    prev2 = index_Node(tmp, pos2 - 1);
    node1 = index_Node(tmp, pos1);
    node2 = index_Node(tmp, pos2);

    if(node1 != NULL && node2 != NULL)
    {   
        if(prev1 != NULL)
            prev1 -> next = node2;
        
        if(prev2 != NULL)
            prev2 -> next = node1;

        tmp = node1 -> next;
        node1 -> next = node2 -> next;
        node2 -> next = tmp;

        if(prev1 == NULL)
        {
            *head = node2;
        }
        else if(prev2 == NULL)
        {
            *head = node1;
        }
    }

    return ;
} 

void print_List(Node*head)
{
    Node* temp = NULL;
    temp = head;
    //print
    printf("\n\n\n");
    while(temp!=NULL)
    {
      printf(" %ld ",temp->value);
      temp=temp->next;
    }
    printf("\n\n\n");
}


